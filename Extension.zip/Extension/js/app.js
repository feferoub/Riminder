// Fonction qui envoie un message au script du content pour obtenir en réponse des infromations sur l'onglet
// courrant. La fonction transmet ensuite les informations obtenues au backend par une requête ajax post.
function buttonClicked(){
	chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tab){
		chrome.tabs.sendMessage(tab[0].id,"Message",function(msg){
			if (msg == undefined){
				alert('Please refresh the page')
			}
			else{
				alert("Page enregistrée !")
				$.ajax({url : "http://127.0.0.1:5000/receiver",data :{'url':msg[0],'page':msg[1],'title':msg[2]}, type : 'POST'})
				}
	});
})}


document.getElementById('clicks').addEventListener('click', buttonClicked);

// Fonction qui récupère auprès du backend les titres de l'ensemble des pages disponibles dans la base de donnée et qui les
// affiche dans une liste déroulante.
function getAPI(){
	$.ajax({url : "http://127.0.0.1:5000/API?title=all"}).done(function(data){

		// Creation du menu déroulant et remplissage de celui-ci
		addSelectMenu()
		alert(data.length)
		for (var i=0; i<data.length; i++){
			addLinkToSelectMenu(data[i])
				}

		// Positionnement d'un listener sur la liste déroulante, lié à la fonction selectPage qui récupère les 
		// infos d'une page sélectionnée
		document.getElementById("titres").addEventListener("click", selectPage, false); 

	})
}

// Fonction qui enregistre le document sélectionné dans la liste déroulante, et envoie au backend une requete
// pour récupérer le code html associé enregistré
function selectPage(){
	var e = document.getElementById("titres")
	var strUser = encodeURIComponent(e.options[e.selectedIndex].text);
	$.ajax({url : "http://127.0.0.1:5000/API?title="+strUser}).done(function(data){
		var win = window.open("", strUser, "ok");
		win.document.body.innerHTML = data;})

}


document.getElementById("accessAPI").addEventListener('click',getAPI);

// Fonction pour afficher dynamiquement le menu déroulant de sélection des onglets enregistrés
function addSelectMenu(){
	var listeSelection = document.createElement("SELECT"),
		container = document.getElementById("addSelectionList");
	listeSelection.id="titres"
	listeSelection.size=10
	container.appendChild(listeSelection)
}


// Fonction pour ajouter au menu déroulant un lien vers une page enregistrée 
function addLinkToSelectMenu(valeur){
   var option = document.createElement("OPTION"),
       select = document.getElementById("titres"),
       texte = document.createTextNode(valeur);
   option.value = valeur;
   option.appendChild(texte);
   select.appendChild(option);
}
