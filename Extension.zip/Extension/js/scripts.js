/*var port;
chrome.tabs.query({ active: true, lastFocusedWindow: true }, function(tab){ 
	var port = chrome.tabs.connect(tab1);
}); 


port.onMessage.addListener(function(msg) {
	alert(msg)
});
function but(){
	port.postMessage({joke: "Knock knock"});
}*/
//console.log('hello')
/*element.onclick = function() {
	/*chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
		var url_=tabs[0].url;
		$.ajax({url : "http://127.0.0.1:5000/receiver",data :{'url':url_}, type : 'POST'})
	});*/
//element.addEventListener("clicks", buttonclicked());
/*chrome.browserAction.onClicked.addListener(buttonclicked);*/
/*	title=window.document.URL
	console.log(title)
	$.ajax({url : "http://127.0.0.1:5000/receiver",data :{'url':title}, type : 'POST'})

}; 

function getContent(){
	alert(window.getSelection().toString())
}
function getUrl(){
	chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
		window.open("http://127.0.0.1:5000/?title="+tabs[0].title+"&url="
		+tabs[0].url,"nom_de_la_fenetre","options_nouvelle_fenetre");
	});
}*/

/*chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) { 
    if(request.action === "getSource") {
        sendResponse({sourceCode: document.documentElement.outerHTML});
    }
});



function method2(id) {
    chrome.tabs.sendMessage(id, {action: "getSource"}, function(response) {
        console.log(response.sourceCode);
    });
}

window.onload = onWindowLoad;

