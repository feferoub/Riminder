// Le script content reste à l'ecoute d'un message qui arrivera du script de background et lui renverra en réponse
// des informations sur la page active

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse){
    var reponse = [document.URL, document.documentElement.outerHTML,document.title]
    sendResponse(reponse)
})
