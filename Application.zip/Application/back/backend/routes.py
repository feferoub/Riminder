from flask import render_template,url_for, request, jsonify
from backend import app, mongo
import urllib
from urllib.request import urlopen, Request
import json


@app.route("/", methods=['GET'])
def home():
	title = request.args.get('title')
	url = request.args.get('url')
	web = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'}))
	fichier = open('test.txt', 'w')
	for i in web:
		fichier.write(str(i))
	fichier.close()
	url2={'url':url}
	mongo.db.save_file('test',fichier)
	mongo.db.sites.url.insert_one(url2)

	    # I'm guessing this would output the html source code ?
	return render_template('home.html',title=title,url=url)


@app.route("/receiver", methods = ['POST'])
def receiver():
	dictionnaire = ({'title':request.form['title'],'page':request.form['page']})
	mongo.db.sites.title.insert_one(dictionnaire)
	#print(mongo.db.sites.url.find_one_or_404({'url':request.form['url']}))
	return render_template('home.html',title="oki",url="okk")

@app.route("/API", methods=['GET'])
def API():
	if request.args.get('title')=='all':
		cursor = mongo.db.sites.title.find()
		Liste = []
		for doc in cursor:
			Liste.append(doc['title'])
		return (jsonify(Liste))
	return mongo.db.sites.title.find_one_or_404({'title':request.args.get('title')})['page']
