from flask import render_template,url_for, request, jsonify
from app import app, mongo
import urllib
from urllib.request import urlopen, Request
import json



# La route receiver recoit par l'extension les informations de la page par l'intérmédiare d'une requête POST.
@app.route("/receiver", methods = ['POST'])
def receiver():
	pageInfo = ({'title':request.form['title'],'page':request.form['page']})
	# Le contenu html de la page est enregistré dans la base de donnée avec le titre de la page
	mongo.db.riminderProject.insert_one(pageInfo)
	return ('Page saved')

# LA route API sert à gérer les requêtes de l'utilisateur pour récupérer des données. Si la requête GET demande tous les titres de la bdd, 
# on renvoie la liste entière en itérant le curseur pointant la bdd (quand l'utilisateur active la liste déroulante). 
# Si la requête a en argument un titre précis ( quand l'utilisateur clique sur un titre de la liste déroulante) on lui renvoie le code html
# associé à ce titre dans la bdd.
@app.route("/API", methods=['GET'])
def API():
	if request.args.get('title')=='all':
		cursor = mongo.db.riminderProject.find()
		titleList = []
		for doc in cursor:
			titleList.append(doc['title'])
		return (jsonify(titleList))
	return mongo.db.riminderProject.find_one_or_404({'title':request.args.get('title')})['page']
